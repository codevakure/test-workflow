// .github/actions/templates/comment-templates.js

const commentTemplates = {
    invalid_branch: {
      error: {
        title: "❌ Invalid Branch Name",
        description: "Branch name must follow the format:\n- feature/ab#123-description\n- bugfix/ab#456-fix\n- us-ab#789-feature\n\nYour branch name: {branch_name}",
        action: "Please rename your branch to follow the required format"
      }
    },
    duplicate_branch: {
      error: {
        title: "❌ Duplicate Story Branch",
        description: "Found existing branches for story #{story_id}:\n{branch_list}",
        action: "Please close this PR and use the existing branch(es) or close the other PR(s) first"
      }
    },
    story_not_found: {
      error: {
        title: "❌ Story Not Found",
        description: "Story #{story_id} was not found in Azure Boards",
        action: "Please verify:\n- The story ID is correct\n- You have access to this story\n- The story exists in your project"
      }
    },
    author_match: {
      error: {
        title: "⚠️ PR Author Mismatch",
        description: "PR author ({author}) does not match story assignee ({assignee})",
        action: "Please verify the correct person is working on this story"
      },
      success: {
        title: "✅ PR Author Match",
        description: "PR author ({author}) matches story assignee ({assignee})"
      }
    }
  };
  
  const validationConfigs = {
    branch_validation: {
      validationNeeded: true,
      githubComment: true,
      azureComment: false
    },
    story_exists: {
      validationNeeded: true,
      githubComment: true,
      azureComment: true
    },
    author_match: {
      validationNeeded: true,
      githubComment: true,
      azureComment: true
    }
  };
  
  module.exports = {
    commentTemplates,
    validationConfigs
  };