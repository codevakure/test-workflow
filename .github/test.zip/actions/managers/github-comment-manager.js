// .github/actions/managers/github-comment-manager.js
const handleGitHubComment = async ({ github, context, templates, validation_type, variables, validation_result }) => {
    const template = templates[validation_type];
    
    let commentText = validation_result && template.success ? template.success : template.error;
    let formattedText = `${commentText.title}\n\n${commentText.description}`;
    if (!validation_result && commentText.action) {
      formattedText += `\n\n${commentText.action}`;
    }
    
    Object.entries(variables).forEach(([key, value]) => {
      formattedText = formattedText.replace(`{${key}}`, value);
    });
    
    const { data: existingComments } = await github.rest.issues.listComments({
      owner: context.repo.owner,
      repo: context.repo.repo,
      issue_number: context.payload.pull_request.number
    });
    
    const existingComment = existingComments.find(comment => 
      comment.user.type === 'Bot' && 
      comment.body.includes(template.error.title)
    );
    
    if (validation_result && existingComment) {
      await github.rest.issues.deleteComment({
        owner: context.repo.owner,
        repo: context.repo.repo,
        comment_id: existingComment.id
      });
    } else if (!validation_result && !existingComment) {
      await github.rest.issues.createComment({
        owner: context.repo.owner,
        repo: context.repo.repo,
        issue_number: context.payload.pull_request.number,
        body: formattedText
      });
    }
  };
  
  module.exports = handleGitHubComment;