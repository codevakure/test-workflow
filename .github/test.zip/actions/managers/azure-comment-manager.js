// .github/actions/managers/azure-comment-manager.js
const handleAzureComment = async ({ templates, validation_type, variables, validation_result, work_item_id, azureOrg, azurePat }) => {
    const template = templates[validation_type];
    
    let commentText = validation_result && template.success ? template.success : template.error;
    let formattedText = `${commentText.title}\n\n${commentText.description}`;
    if (!validation_result && commentText.action) {
      formattedText += `\n\n${commentText.action}`;
    }
    
    Object.entries(variables).forEach(([key, value]) => {
      formattedText = formattedText.replace(`{${key}}`, value);
    });
    
    try {
      const token = Buffer.from(`:${azurePat}`).toString('base64');
      await fetch(
        `${azureOrg}/_apis/wit/workitems/${work_item_id}/comments?api-version=6.0`,
        {
          method: 'POST',
          headers: {
            'Authorization': `Basic ${token}`,
            'Content-Type': 'application/json'
          },
          body: JSON.stringify({ text: formattedText })
        }
      );
    } catch (error) {
      console.log(`Error posting Azure comment: ${error.message}`);
    }
  };
  
  module.exports = handleAzureComment;