# Azure Boards PR Integration Documentation

## Overview
This GitHub Actions workflow automates the integration between GitHub Pull Requests and Azure Boards work items. It provides automated validation, tracking, and status updates to ensure alignment between development work and Azure Boards stories.

## Setup Instructions

### Prerequisites
1. GitHub repository
2. Azure DevOps organization
3. Azure DevOps Personal Access Token (PAT)

### Configuration Steps
1. Create an Azure DevOps PAT:
   - Go to Azure DevOps > User Settings > Personal Access Tokens
   - Create new token with permissions:
     - Work Items: Read & Write
     - Pull Request Threads: Read

2. Add GitHub Repository Secrets:
   - Navigate to your GitHub repository → Settings → Secrets and Variables → Actions
   - Add the following secrets:
     - `AZURE_DEVOPS_PAT`: Your Azure DevOps PAT
     - `AZURE_DEVOPS_ORG`: Your Azure DevOps organization URL (e.g., `https://dev.azure.com/your-org`)

3. Add the workflow file:
   - Create directory: `.github/workflows/`
   - Add file: `azure-boards-pr.yml`
   - Copy the complete workflow code

## Branch Naming Convention

### Required Format
```
type-ab#[id]-description
```

### Examples
- `feature-ab#123-user-authentication`
- `bug-ab#456-fix-login-issue`
- `hotfix-ab#789-security-patch`
- `sprint-ab#234-payment-gateway`
- `us-ab#567-dashboard-updates`

### Default Branches (Skipped Validation)
- main
- develop
- develop2
- test
- test/*
- develop/*
- hotfix (exact match only)

## Validation Rules & Workflow Behavior

### 1. Story Validation
The workflow checks:
- Story exists in Azure Boards
- Story has an assignee
- Story is in "In Progress" state
- Story has valid story points (1, 2, 3, or 5)

### 2. Assignee Name Matching
- Compares PR author's GitHub username with Azure Boards assignee
- Matches if any word part matches (e.g., "John Smith" matches "john_dev")
- Case-insensitive comparison
- Handles underscores and hyphens in GitHub usernames

### 3. Story Points Duration Tracking
Points to Maximum Days mapping:
- 1 point → 0.5-1 day
- 2 points → max 2 days
- 3 points → max 3 days
- 5 points → max 5 days

### 4. Workflow Failure Conditions
The PR checks will fail if:
- Story number doesn't exist
- Story has no assignee
- Story is not in "In Progress" state
- PR author name doesn't match story assignee
- Invalid story points value

### 5. Warning Conditions (Non-Blocking)
Warnings are posted when:
- PR duration exceeds recommended days for story points
- These warnings don't block PR merging

## Status Updates

### GitHub PR Comments
1. Comments are managed (old bot comments are deleted)
2. Posted on events:
   - PR opened/edited
   - PR merged to develop
3. Comment types:
   ```
   ⚠️ Warnings:
   - No board ID in branch name
   - Story not found
   - Author mismatch
   - Story not in "In Progress"
   - Duration exceeded

   ✅ Success:
   - PR merged to develop
   ```

### Azure Board Updates
1. Sequential comments are posted to work item history
2. Update format:
   ```
   **PR Status Update** 🔄
   **Author:** @username ✅ (Matches assigned user)
   **Reviewers:** @reviewer1, @reviewer2
   **Recent Discussion:** @commenter1, @commenter2
   **Status:** ⏳ Open (or ✅ Closed)
   Open Comments: X
   Resolved Comments: Y
   Failing Workflows: None (or lists failing workflows)
   Last Commit: YYYY-MM-DD HH:MM:SS
   Total Commits: N
   Days Open: D

   [Duration Warning if applicable]

   PR Link: https://github.com/...
   ```

## Trigger Events
The workflow runs on:
- Pull Requests:
  - opened
  - reopened
  - edited
  - closed
- PR Reviews:
  - submitted
  - edited
  - dismissed
- PR Review Comments:
  - created
  - edited
  - deleted
- Issue Comments:
  - created
  - edited
  - deleted

## Troubleshooting

### Common Issues
1. **Invalid Branch Name**
   - Ensure branch follows naming convention
   - Check story ID is correctly formatted after 'ab#'

2. **Story State Issues**
   - Verify story is moved to "In Progress" before opening PR
   - Check story exists and is accessible

3. **Name Mismatch**
   - Ensure GitHub username contains part of Azure Boards assignee name
   - Check story has correct assignee

4. **Story Points**
   - Verify story has valid points (1, 2, 3, or 5)
   - Monitor PR duration against story points

### Error Messages
- `Story #123 has no assignee`: Add assignee in Azure Boards
- `Story #123 is not in 'In Progress' state`: Update story state
- `PR author does not match story assignee`: Check assignee and GitHub username
- `Azure Board story #123 not found`: Verify story ID and access permissions

## Best Practices
1. Always assign stories before creating PRs
2. Move stories to "In Progress" before opening PRs
3. Use consistent naming in GitHub and Azure DevOps
4. Monitor PR duration against story points
5. Address warnings promptly, even if they don't block merging

## Security Considerations
1. Keep Azure DevOps PAT secure
2. Review PAT permissions regularly
3. Rotate PATs periodically
4. Monitor workflow access and usage