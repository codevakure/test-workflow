# Branch and PR Title Check Documentation

## Overview

This GitHub Action workflow enforces consistent branch naming and PR title conventions across the repository. It validates both the branch name and PR title against predefined patterns and provides feedback when violations are detected.

## Naming Conventions

### Valid Prefixes
Both branch names and PR titles must start with one of these prefixes:
- `feature`
- `sprint`
- `us`
- `hotfix`
- `bug`

### Exception Prefixes
The following prefixes are exempt from the standard naming convention:
- `develop`
- `test`
- `main`
- `test/`
- `develop/`
- `release/`

## Branch Name Format

### Pattern
```
<prefix>-ab#<number>-<description>
```

### Rules
1. Must start with a valid prefix (lowercase)
2. Followed by a hyphen (-)
3. Must include "ab#" followed by a number
4. Ends with a hyphen and description (lowercase, can include numbers)
5. Description can contain hyphens but no spaces or special characters

### Examples
Valid branch names:
- `feature-ab#123-user-authentication`
- `bug-ab#456-fix-login-issue`
- `hotfix-ab#789-security-patch`
- `sprint-ab#234-payment-gateway`
- `us-ab#567-dashboard-updates`

Invalid branch names:
- `feature_ab#123_auth` (wrong separators)
- `BUG-ab#456-login` (uppercase not allowed)
- `feature-123-auth` (missing ab#)
- `feature-ab#123` (missing description)
- `other-ab#123-test` (invalid prefix)

### Exception Cases
These branch names are automatically valid:
- `develop`
- `main`
- `test/any-name`
- `develop/any-name`
- `release/any-name`

## PR Title Format

### Pattern
```
<prefix>[-space]ab#<number> <description>
```

### Rules
1. Must start with a valid prefix (lowercase)
2. Can have either a hyphen or space after prefix
3. Must include "ab#" followed by a number
4. Followed by a space and description
5. Description can be in any case and include spaces

### Examples
Valid PR titles:
- `feature ab#123 Add user authentication`
- `bug-ab#456 Fix login page crash`
- `hotfix ab#789 Security vulnerability patch`
- `sprint-ab#234 Implement payment gateway`
- `us ab#567 New dashboard features`

Invalid PR titles:
- `feature_ab#123 Auth` (wrong separator)
- `BUG-ab#456 Login` (prefix must be lowercase)
- `feature-123 Auth` (missing ab#)
- `other-ab#123 Test` (invalid prefix)

### Exception Cases
PR titles starting with these prefixes are automatically valid:
- `develop`
- `test`
- `main`
- `test/`
- `develop/`
- `release/`

## Validation Process

### What Gets Checked
1. **Branch Name Validation**
   - Checks against exception prefixes
   - Validates prefix from allowed list
   - Verifies format compliance
   - Case-insensitive comparison

2. **PR Title Validation**
   - Checks against exception prefixes
   - Validates prefix from allowed list
   - Verifies format compliance
   - Case-insensitive comparison

### Validation Results
- **Success**: 
  - Previous validation comments are removed
  - PR checks pass
  - No new comments added

- **Failure**: 
  - Previous validation comments are removed
  - New failure comment is added
  - PR checks fail
  - Detailed error message provided

## Error Handling

### Branch Name Errors
If the branch name is invalid:
1. Validation comment will indicate branch name failure
2. PR will be blocked
3. Link to guidelines will be provided

### PR Title Errors
If the PR title is invalid:
1. Validation comment will indicate PR title failure
2. PR will be blocked
3. Link to guidelines will be provided

## Setup Instructions

### Repository Setup

1. Create `.github/workflows/` directory
2. Add the branch and PR title check workflow file:
   ```yaml
   name: Branch and PR Title Check
   [rest of the workflow file content...]
   ```

### Required Permissions
The workflow needs:
- `pull-requests: write`
- `contents: read`
- `issues: write`
- `statuses: write`

### Configuration
- Uses default `GITHUB_TOKEN`
- No additional configuration needed

## Troubleshooting

### Common Issues

1. **Case Sensitivity**
   - All prefixes must be lowercase
   - Branch description must be lowercase
   - PR title description can be any case

2. **Special Characters**
   - Branch names: only hyphens allowed in description
   - PR titles: spaces and hyphens allowed in description

3. **Missing Components**
   - Ensure "ab#" is included
   - Verify number is present after "ab#"
   - Check that description is provided

### Quick Fixes

1. **Branch Name Issues**
   - Create new branch with correct format
   - Push changes to new branch
   - Update PR to use new branch

2. **PR Title Issues**
   - Edit PR title to match format
   - Ensure prefix is lowercase
   - Add missing "ab#" number

## Support

If you encounter issues:
1. Check the validation comment for specific errors
2. Review this documentation
3. Verify against the example formats
4. Contact repository maintainers if issues persist
