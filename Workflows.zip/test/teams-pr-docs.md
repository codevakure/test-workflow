# Teams PR Notification Workflow

This GitHub Action automatically sends notifications to Microsoft Teams when pull requests are opened. It creates a detailed card in Teams with information about the PR, including required reviewers, code owners, and changes.

## Features

- Triggers automatically when PRs are opened
- Creates a formatted Teams message card
- Shows required approvals from branch protection rules
- Identifies required reviewers from CODEOWNERS
- Displays requested reviewers
- Shows PR statistics (changes, files modified)
- Provides direct link to the PR

## Setup

### Prerequisites

1. Microsoft Teams channel webhook URL
2. GitHub repository with pull request workflow
3. (Optional) CODEOWNERS file setup
4. (Optional) Branch protection rules configured

### Installation

1. Add the workflow file to your repository:
   ```bash
   mkdir -p .github/workflows/
   ```
   Copy the workflow file to `.github/workflows/teams-pr-notification.yml`

2. Set up the Teams webhook:
   - In your Teams channel, click the ... menu
   - Select "Connectors"
   - Configure an "Incoming Webhook"
   - Copy the webhook URL

3. Add the webhook URL to GitHub secrets:
   - Go to your repository settings
   - Navigate to Secrets and Variables > Actions
   - Create a new secret named `TEAMS_WEBHOOK_URL`
   - Paste your Teams webhook URL

### Configuration

#### Branch Protection (Optional)

To enable required approvals:
1. Go to repository settings
2. Navigate to Branches > Branch protection rules
3. Add a rule for your target branches (main, develop, etc.)
4. Configure required number of approvals

#### CODEOWNERS Setup (Optional)

Create a CODEOWNERS file in one of these locations:
- `.github/CODEOWNERS`
- `docs/CODEOWNERS`
- `CODEOWNERS`

Example CODEOWNERS format:
```
# Default owners for everything
*       @global-owner1 @global-owner2

# Owners for specific directories
/src/   @dev-team
/docs/  @doc-team

# Owners for specific file types
*.js    @js-team
*.py    @python-team
```

## Teams Card Format

The notification card in Teams includes:

### Header Section
- PR title and branch information
- Visual indicator that it's a new PR

### Details Section
1. **Basic Information**
   - PR title
   - Author
   - Branch details (source → target)

2. **Review Requirements**
   - Number of required approvals
   - Code owners who must review
   - Currently requested reviewers

3. **Changes Overview**
   - Number of files changed
   - Lines added/removed
   - PR description

4. **Quick Actions**
   - Direct link to view the PR

## Workflow Details

### Trigger Conditions
The workflow runs on:
```yaml
on:
  pull_request:
    types: [opened]
    branches:
      - "main"
      - "develop"
      - "hotfix"
```

### Key Functions

1. **Code Owners Detection**
   - Reads CODEOWNERS file
   - Matches changed files against ownership patterns
   - Identifies required reviewers

2. **Branch Protection Check**
   - Fetches branch protection rules
   - Determines required approval count

3. **Teams Card Creation**
   - Formats information in Teams card format
   - Includes markdown support
   - Adds actionable links

## Troubleshooting

Common issues and solutions:

1. **Teams Notification Not Sending**
   - Verify webhook URL is correct in GitHub secrets
   - Check GitHub Actions logs for error messages
   - Ensure repository has proper permissions

2. **Missing Code Owners**
   - Verify CODEOWNERS file exists and is properly formatted
   - Check file path patterns in CODEOWNERS
   - Review GitHub Actions logs for CODEOWNERS parsing errors

3. **Branch Protection Not Showing**
   - Confirm branch protection rules are configured
   - Verify GitHub token has necessary permissions
   - Check for errors in GitHub Actions logs

## Contributing

To modify the workflow:

1. Fork the repository
2. Make your changes
3. Test with your Teams webhook
4. Submit a PR with detailed description of changes

## License

This workflow is available under the MIT License. Feel free to modify and use it in your projects.
