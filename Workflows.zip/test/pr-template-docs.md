# PR Template Check Documentation

## Overview
The PR Template Check is a GitHub Action workflow that enforces consistent pull request descriptions by validating required sections and their contents. This document explains how to use the template, what is required, and how to set up the workflow.

## Pull Request Template Structure

### Required Sections
Your pull request description must include all of the following sections:

1. **Description**
   - Must contain meaningful content describing your changes
   - Cannot be empty or contain only comments
   - Should include context, motivation, and relevant background information

2. **Type of Change**
   - At least one option must be selected
   - Available options:
     - Bugfix
     - Feature
     - Code style update
     - Refactoring (no functional changes)
     - Refactoring (with functional changes)
     - Build process changes
     - Documentation changes
     - Other (requires description)

3. **Breaking Changes**
   - Must select either Yes or No
   - Cannot leave both options unchecked

4. **UI Platform Standards Compliance**
   - Must select either Yes or No
   - Cannot leave both options unchecked

## Usage Guide

### Creating a New Pull Request

1. Click on "New Pull Request" in your repository
2. The template will automatically load with all required sections
3. Fill in each section according to the requirements below

### Required Format
```markdown
## Description
[Your detailed description here]

## Type of Change
- [ ] Bugfix
- [ ] Feature
[other options...]

## Breaking Changes
- [ ] Yes
- [ ] No

## UI Platform Standards Compliance
- [ ] Yes
- [ ] No
```

### Section Requirements

#### Description Section
- Must provide clear context about the changes
- Include:
  - What changes were made
  - Why the changes were necessary
  - Any notable implementation details
  - Impact on existing functionality

#### Type of Change Section
- Select at least one checkbox
- If selecting "Other", provide a description
- Use multiple checkboxes if changes span multiple categories

#### Breaking Changes Section
- Must select exactly one option
- Select "Yes" if your changes:
  - Modify existing APIs
  - Change expected behaviors
  - Require updates to dependent code

#### UI Platform Standards Section
- Must select exactly one option
- Select "Yes" only if you've verified compliance with all platform standards

## Validation Process

### What Gets Checked
The workflow validates:
1. Presence of all required sections
2. Non-empty description content
3. At least one selected Type of Change
4. One selected option for Breaking Changes
5. One selected option for UI Platform Standards

### Validation Results
- **Success**: Previous validation comments are removed
- **Failure**: 
  - Existing validation comments are removed
  - New comment lists missing/incomplete sections
  - PR will be marked as failing checks

### Error Messages
If validation fails, you'll receive a comment with:
- List of missing or incomplete sections
- Required sections reminder
- Specific requirements for each section

## Troubleshooting

### Common Issues

1. **Template Sections Missing**
   - Solution: Ensure all section headers are present and properly formatted
   - Headers must start with "## " followed by the exact section name

2. **Checkbox Selection Issues**
   - Solution: Use "[x]" for selected items
   - Ensure proper formatting: "- [x] Option"

3. **Empty Description**
   - Solution: Add meaningful content to the Description section
   - Remove placeholder text and add actual description

### Tips for Success

1. **Before Submitting**
   - Preview your PR description
   - Verify all required sections are present
   - Check that appropriate boxes are marked
   - Ensure description is meaningful

2. **After Failed Validation**
   - Read the validation comment carefully
   - Address all listed issues
   - Re-check the format of your checkboxes
   - Verify section headers match exactly

## Setup Instructions

### Repository Setup

1. Create `.github/workflows/` directory in your repository
2. Add the PR template check workflow file:
   ```yaml
   name: PR Template Check
   [rest of the workflow file content...]
   ```
3. Create `.github/pull_request_template.md` with the template content

### Permissions Required
The workflow needs:
- `pull-requests: write`
- `contents: read`
- `issues: write`

### Configuration
No additional configuration is needed. The workflow uses the default `GITHUB_TOKEN`.

## Support

For issues or questions:
1. Check the validation comment for specific errors
2. Review this documentation for requirements
3. Contact the repository maintainers if issues persist
